package com.dentalflow.dentalflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentalflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
