# Dentalflow

Backend Spring Boot para un consultorio odontológico.

## Funcionalidades
- Autenticación JWT con roles
- Pacientes, odontólogos, tratamientos, turnos y pagos
- Historia clínica
- Dashboard y reportes
- Exportación de reportes en PDF y Excel
- Filtros avanzados
- Recordatorios de turnos por email y preparación de WhatsApp
- Recordatorios automáticos programables

## Endpoints destacados
- `GET /reportes/resumen`
- `GET /reportes/resumen/pdf`
- `GET /reportes/resumen/excel`
- `GET /reportes/rango?desde=YYYY-MM-DD&hasta=YYYY-MM-DD`
- `GET /reportes/rango/pdf?desde=YYYY-MM-DD&hasta=YYYY-MM-DD`
- `GET /reportes/rango/excel?desde=YYYY-MM-DD&hasta=YYYY-MM-DD`
- `GET /recordatorios/proximos?horas=24`
- `POST /recordatorios/turnos/{id}/email`
- `POST /recordatorios/turnos/{id}/whatsapp`
- `POST /recordatorios/turnos/{id}/whatsapp-odontologo`
- `GET /turnos/buscar`
- `PATCH /turnos/{id}/confirmar`
- `PATCH /turnos/{id}/cancelar`
- `PATCH /turnos/{id}/reprogramar`
- `GET /pagos/buscar`
- `GET /actuator/health`
- `GET /actuator/info`
- `GET /integraciones/sync/turnos`
- `GET /integraciones/sync/pacientes`
- `GET /integraciones/sync/tratamientos`
- `GET /integraciones/whatsapp/auditoria`
- `GET /webhooks/whatsapp?hub.verify_token=...&hub.challenge=...`
- `POST /webhooks/whatsapp`

## Variables de entorno
- `JWT_SECRET`
- `JWT_EXPIRATION_MS`
- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`
- `MAIL_HOST`
- `MAIL_PORT`
- `MAIL_USERNAME`
- `MAIL_PASSWORD`
- `APP_RECORDATORIOS_ENABLED`
- `APP_RECORDATORIOS_HORAS`
- `APP_RECORDATORIOS_CRON`
- `APP_WHATSAPP_WEBHOOK_TOKEN`
- `APP_WHATSAPP_CLOUD_ENABLED`
- `APP_WHATSAPP_API_BASE`
- `APP_WHATSAPP_PHONE_NUMBER_ID`
- `APP_WHATSAPP_ACCESS_TOKEN`
- `APP_WHATSAPP_SIGNATURE_ENABLED`
- `APP_WHATSAPP_APP_SECRET`

## Ejecutar tests
```powershell
.\mvnw test
```


